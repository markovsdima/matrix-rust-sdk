from pathlib import Path
import subprocess,os,json,time,hashlib,statistics
r=Path(__file__).resolve().parents[1]
variants=['current','no_coalescing','no_pending','neither'];runs=[];golden={};golden_hash={}
env=os.environ.copy();env['RUST_LOG']='off'
# Each process executes all six cases and the 1000-event live control.
# Exactly one warmup and five measured runs per variant. All builds precede this.
orders=[variants]+[variants[k%4:]+variants[:k%4] for k in range(5)]
for round_,order in enumerate(orders):
 for variant in order:
  states=r/'states'/variant;states.mkdir(exist_ok=True)
  env['AUDIT_STATE_DIR']=str(states)
  cmd=[str(r/'binaries'/variant),'cache_rebuild_volume','--ignored','--nocapture','--test-threads=1']
  log=r/'logs'/f'measure-{round_}-{variant}.log';start=time.time()
  print(f'RUN round={round_} variant={variant}',flush=True)
  with log.open('w') as out:code=subprocess.run(cmd,cwd=r/'final',env=env,stdout=out,stderr=subprocess.STDOUT,timeout=1800).returncode
  measurements=[]
  for line in log.read_text().splitlines():
   for prefix,kind in [('CACHE_REBUILD_VOLUME ','rebuild'),('CACHE_LIVE_VOLUME ','live')]:
    if prefix in line:
     row=json.loads(line.split(prefix,1)[1]);row['kind']=kind;measurements.append(row)
  run={'variant':variant,'round':round_,'warmup':round_==0,'command':cmd,'RUST_LOG':'off','started_unix':start,'wall_s':time.time()-start,'exit_code':code,'log':str(log),'measurements':measurements,'state_sha256':{}}
  runs.append(run);(r/'results/raw-measurements.json').write_text(json.dumps(runs,indent=2)+'\n')
  assert code==0,(round_,variant,log)
  assert len(measurements)==7,(variant,len(measurements))
  for path in sorted(states.glob('*.json')):
   data=path.read_bytes();value=json.loads(data);sha=hashlib.sha256(data).hexdigest()
   if path.name not in golden:
    assert variant=='current';golden[path.name]=value;golden_hash[path.name]=sha
   assert value==golden[path.name],f'Final state/diff mismatch: {variant}/{path.name}'
   assert sha==golden_hash[path.name],f'Noncanonical serialization: {variant}/{path.name}'
   run['state_sha256'][path.name]=sha
  assert len(run['state_sha256'])==8
  (r/'results/raw-measurements.json').write_text(json.dumps(runs,indent=2)+'\n')
  print(f'PASS round={round_} {variant}: rebuild_us={[m["elapsed_us"] for m in measurements if m["kind"]=="rebuild"]}',flush=True)
summary=[]
for variant in variants:
 for kind,history,attachments,receipts in [('rebuild',n,a,b) for n in [1000,17000] for a,b in [(False,True),(True,True),(True,False)]]+[('live',1000,False,True)]:
  rows=[m for run in runs if run['variant']==variant and not run['warmup'] for m in run['measurements'] if m['kind']==kind and m['history']==history and (kind=='live' or (m['attachments']==attachments and m['receipt_tracking']==receipts))]
  assert len(rows)==5
  entry={'variant':variant,'kind':kind,'history':history,'attachments':attachments,'receipt_tracking':receipts,'metrics':{}}
  for key in rows[0]:
   if key in ['kind','history','attachments','receipt_tracking']:continue
   values=[m[key] for m in rows]
   if all(isinstance(v,(int,float)) and not isinstance(v,bool) for v in values):
    entry['metrics'][key]={'values':values,'median':statistics.median(values),'min':min(values),'max':max(values)}
   else:entry['metrics'][key]={'values':values}
  summary.append(entry)
(r/'results/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(r/'results/equivalence.json').write_text(json.dumps({'comparisons':len(runs)*8,'runs':len(runs),'canonical_states_and_live_diff_hashes':golden_hash,'all_equal':True,'opaque_timeline_unique_ids':'not compared between independent controllers; uniqueness asserted within each final state; parsed item Debug state, explicitly serialized message types, original/latest raw JSON and all remote metadata compared'},indent=2)+'\n')
print('MEASUREMENT COMPLETE: 24 invocations, 144 rebuilds + 24 live controls; 192 full-state/diff comparisons.',flush=True)
